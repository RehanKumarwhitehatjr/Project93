import * as React from 'react';
import { View, Text, TouchableOpacity,StyleSheet } from 'react-native';
export default class HomeScreen extends React.Component {
  render(){
    return(
      <Text>Cancel Screen</Text>
    );
  }}